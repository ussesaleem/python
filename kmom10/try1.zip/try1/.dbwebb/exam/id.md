ID: 13
target: try1
acronym: ussa19
